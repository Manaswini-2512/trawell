import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Card, CardContent } from '@/components/ui/card';
import { MapPin, Heart, Users, Award, Globe, Sparkles } from 'lucide-react';

const About = () => {
  const values = [
    {
      icon: MapPin,
      title: 'Cultural Immersion',
      description: 'We believe travel should be transformative, connecting you deeply with local cultures and traditions.'
    },
    {
      icon: Heart,
      title: 'Artisan Support',
      description: 'Every purchase directly supports local artisans, preserving traditional crafts for future generations.'
    },
    {
      icon: Users,
      title: 'Community Impact',
      description: 'We work with local communities to ensure tourism benefits everyone, not just visitors.'
    },
    {
      icon: Sparkles,
      title: 'AI-Powered Planning',
      description: 'Our intelligent system creates personalized itineraries that match your interests and budget.'
    }
  ];

  const stats = [
    { number: '50+', label: 'Destinations' },
    { number: '200+', label: 'Local Artisans' },
    { number: '1000+', label: 'Happy Travelers' },
    { number: '95%', label: 'Satisfaction Rate' }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-6 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-playfair font-bold text-foreground mb-6">
            About <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Trawell
            </span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            We're passionate about creating meaningful connections between travelers and the rich cultural heritage of India. 
            Through AI-powered planning and authentic artisan partnerships, we make cultural exploration both accessible and impactful.
          </p>
        </div>

        {/* Mission & Vision */}
        <div className="grid md:grid-cols-2 gap-12 mb-16">
          <Card className="cultural-card p-8">
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-3 mb-4">
                <div className="p-3 bg-primary/10 rounded-full">
                  <Globe className="h-6 w-6 text-primary" />
                </div>
                <h2 className="text-2xl font-playfair font-bold text-foreground">Our Mission</h2>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                To revolutionize cultural travel by connecting adventurous souls with authentic local experiences, 
                while empowering artisan communities and preserving traditional crafts. We believe every journey 
                should leave both the traveler and the destination enriched.
              </p>
            </CardContent>
          </Card>

          <Card className="cultural-card p-8">
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-3 mb-4">
                <div className="p-3 bg-secondary/10 rounded-full">
                  <Award className="h-6 w-6 text-secondary" />
                </div>
                <h2 className="text-2xl font-playfair font-bold text-foreground">Our Vision</h2>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                To become the world's leading platform for cultural tourism, where technology meets tradition. 
                We envision a future where every traveler becomes a cultural ambassador, and every artisan 
                has access to global markets while maintaining their heritage.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Values */}
        <div className="mb-16">
          <h2 className="text-3xl font-playfair font-bold text-center mb-12">
            Our <span className="text-primary">Values</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <Card key={index} className="cultural-card p-6 text-center">
                <CardContent className="space-y-4">
                  <div className="flex justify-center">
                    <div className="p-4 bg-primary/10 rounded-full">
                      <value.icon className="h-8 w-8 text-primary" />
                    </div>
                  </div>
                  <h3 className="text-lg font-semibold text-foreground">{value.title}</h3>
                  <p className="text-muted-foreground text-sm">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="bg-gradient-to-r from-primary/10 to-secondary/10 rounded-2xl p-8 mb-16">
          <h2 className="text-3xl font-playfair font-bold text-center mb-8">
            Our Impact in <span className="text-primary">Numbers</span>
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-primary mb-2">{stat.number}</div>
                <div className="text-muted-foreground font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Story */}
        <Card className="cultural-card p-8 mb-16">
          <CardContent className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-playfair font-bold text-center mb-8">
              Our <span className="text-accent">Story</span>
            </h2>
            <div className="prose prose-lg max-w-none text-muted-foreground">
              <p className="mb-6">
                Trawell was born from a simple observation: while technology had transformed how we book flights and hotels, 
                the heart of travel—authentic cultural connection—remained largely unchanged. Founded in 2024 by a team of 
                travel enthusiasts and technology innovators, we set out to bridge this gap.
              </p>
              <p className="mb-6">
                Our founders, having traveled extensively across India, witnessed firsthand the incredible craftsmanship of 
                local artisans and the rich stories embedded in every destination. Yet they also saw how these treasures 
                often remained hidden from travelers, while artisans struggled to reach broader markets.
              </p>
              <p>
                Today, Trawell stands at the intersection of cutting-edge AI technology and age-old traditions, creating 
                a platform where every journey tells a story, every purchase makes a difference, and every traveler becomes 
                part of a larger narrative of cultural preservation and celebration.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Why Choose Us */}
        <div className="text-center">
          <h2 className="text-3xl font-playfair font-bold mb-6">
            Why Choose <span className="text-secondary">Trawell?</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            We're not just another travel platform. We're your gateway to authentic experiences, meaningful connections, 
            and the opportunity to make a positive impact through your travels. Join us in celebrating and preserving 
            the incredible cultural heritage of India, one journey at a time.
          </p>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default About;