import { useState } from 'react';
import { Link } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Search, MapPin, Calendar, Star } from 'lucide-react';
import varanashiImage from '@/assets/varanasi-ghats.jpg';
import jaipurImage from '@/assets/jaipur-palace.jpg';

const destinations = [
  {
    id: 1,
    name: 'Varanasi',
    subtitle: 'Spiritual Journey',
    description: 'Experience the ancient spiritual heart of India with temple visits and Ganga aarti',
    image: varanashiImage,
    rating: 4.8,
    type: 'Spiritual',
    duration: '3-4 days'
  },
  {
    id: 2,
    name: 'Jaipur',
    subtitle: 'Pink City Heritage',
    description: 'Explore majestic palaces, vibrant markets, and rich Rajasthani culture',
    image: jaipurImage,
    rating: 4.7,
    type: 'Heritage',
    duration: '2-3 days'
  },
  {
    id: 3,
    name: 'Udaipur',
    subtitle: 'City of Lakes',
    description: 'Discover romantic palaces, serene lakes, and traditional art forms',
    image: '/placeholder.svg',
    rating: 4.9,
    type: 'Heritage',
    duration: '2-3 days'
  },
  {
    id: 4,
    name: 'Mysore',
    subtitle: 'Cultural Capital',
    description: 'Witness royal grandeur, silk weaving, and vibrant Dasara celebrations',
    image: '/placeholder.svg',
    rating: 4.6,
    type: 'Culture',
    duration: '2 days'
  },
  {
    id: 5,
    name: 'Hampi',
    subtitle: 'Ruins of Empire',
    description: 'Step back in time among ancient temple complexes and boulder landscapes',
    image: '/placeholder.svg',
    rating: 4.5,
    type: 'Heritage',
    duration: '2-3 days'
  },
  {
    id: 6,
    name: 'Pushkar',
    subtitle: 'Sacred Oasis',
    description: 'Experience desert culture, camel markets, and holy lake rituals',
    image: '/placeholder.svg',
    rating: 4.4,
    type: 'Spiritual',
    duration: '1-2 days'
  }
];

const Destinations = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('All');

  const filteredDestinations = destinations.filter(dest => {
    const matchesSearch = dest.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         dest.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === 'All' || dest.type === selectedType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-playfair font-bold text-foreground mb-4">
            Explore <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Destinations
            </span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Discover India's rich cultural tapestry through our curated collection of authentic destinations
          </p>
        </div>

        <div className="mb-8 space-y-4 md:space-y-0 md:flex md:items-center md:justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={20} />
            <Input
              type="text"
              placeholder="Search your destination..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            {['All', 'Heritage', 'Spiritual', 'Culture'].map((type) => (
              <Button
                key={type}
                variant={selectedType === type ? "default" : "outline"}
                onClick={() => setSelectedType(type)}
                size="sm"
              >
                {type}
              </Button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredDestinations.map((destination) => (
            <Card key={destination.id} className="cultural-card overflow-hidden">
              <div className="aspect-video bg-muted relative overflow-hidden">
                <img
                  src={destination.image}
                  alt={destination.name}
                  className="w-full h-full object-cover"
                />
                <Badge className="absolute top-4 left-4 bg-primary">
                  {destination.type}
                </Badge>
              </div>
              
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-xl font-playfair">
                      {destination.name}
                    </CardTitle>
                    <p className="text-primary font-medium">{destination.subtitle}</p>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium">{destination.rating}</span>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <p className="text-muted-foreground">{destination.description}</p>
                
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Calendar size={16} />
                    <span>{destination.duration}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <MapPin size={16} />
                    <span>India</span>
                  </div>
                </div>
                
                <Button className="w-full btn-hero" asChild>
                  <Link to="/contact">
                    Plan Trip with AI
                  </Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Destinations;