import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="cultural-pattern bg-muted mt-20">
      <div className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-2xl font-playfair font-bold text-primary mb-4">Trawell</h3>
            <p className="text-muted-foreground">
              Bringing culture to your journey through AI-powered travel planning and authentic artisan experiences.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold text-foreground mb-4">Quick Links</h4>
            <div className="space-y-2">
              <Link to="/" className="block text-muted-foreground hover:text-primary transition-colors">Home</Link>
              <Link to="/destinations" className="block text-muted-foreground hover:text-primary transition-colors">Destinations</Link>
              <Link to="/marketplace" className="block text-muted-foreground hover:text-primary transition-colors">Marketplace</Link>
              <Link to="/about" className="block text-muted-foreground hover:text-primary transition-colors">About</Link>
              <Link to="/contact" className="block text-muted-foreground hover:text-primary transition-colors">Contact</Link>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold text-foreground mb-4">Follow Us</h4>
            <div className="flex space-x-4">
              <a href="#" className="p-2 bg-primary/10 rounded-full hover:bg-primary hover:text-primary-foreground transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="p-2 bg-secondary/10 rounded-full hover:bg-secondary hover:text-secondary-foreground transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="p-2 bg-accent/10 rounded-full hover:bg-accent hover:text-accent-foreground transition-colors">
                <Twitter size={20} />
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-border mt-8 pt-8 text-center">
          <p className="text-muted-foreground">
            © 2025 Trawell | Bringing Culture to Your Journey
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;