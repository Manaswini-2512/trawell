import { Link } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  MapPin, 
  Star, 
  ArrowRight, 
  Sparkles, 
  Globe, 
  Heart,
  Calendar,
  Users,
  ShoppingBag,
  Compass
} from 'lucide-react';
import heroImage from '@/assets/hero-cultural-market.jpg';
import artisanImage from '@/assets/artisan-pottery.jpg';
import varanashiImage from '@/assets/varanasi-ghats.jpg';
import jaipurImage from '@/assets/jaipur-palace.jpg';
import silkImage from '@/assets/silk-textile.jpg';
import udaipurImage from '@/assets/udaipur-lakes.jpg';
import woodenElephantImage from '@/assets/wooden-elephant.jpg';

const Index = () => {
  const featuredDestinations = [
    {
      id: 1,
      name: 'Varanasi',
      subtitle: 'Spiritual Journey',
      description: 'Ancient ghats, temple rituals, and timeless spirituality',
      image: varanashiImage,
      rating: 4.8,
      duration: '3-4 days'
    },
    {
      id: 2,
      name: 'Jaipur',
      subtitle: 'Pink City Heritage',
      description: 'Majestic palaces, vibrant markets, royal heritage',
      image: jaipurImage,
      rating: 4.7,
      duration: '2-3 days'
    },
    {
      id: 3,
      name: 'Udaipur',
      subtitle: 'City of Lakes',
      description: 'Romantic palaces, serene lakes, artistic traditions',
      image: udaipurImage,
      rating: 4.9,
      duration: '2-3 days'
    }
  ];

  const featuredArtisans = [
    {
      id: 1,
      name: 'Hand-painted Pottery',
      artisan: 'Raj Kumar',
      location: 'Jaipur',
      price: '₹1,200',
      image: artisanImage,
      rating: 4.8
    },
    {
      id: 2,
      name: 'Silk Saree',
      artisan: 'Lakshmi Devi',
      location: 'Varanasi',
      price: '₹2,800',
      image: silkImage,
      rating: 4.9
    },
    {
      id: 3,
      name: 'Wooden Elephant',
      artisan: 'Mohan Singh',
      location: 'Udaipur',
      price: '₹2,200',
      image: woodenElephantImage,
      rating: 4.7
    }
  ];

  const features = [
    {
      icon: Sparkles,
      title: 'AI-Powered Planning',
      description: 'Smart itineraries tailored to your interests and budget'
    },
    {
      icon: Globe,
      title: 'Authentic Experiences',
      description: 'Connect with local culture through curated activities'
    },
    {
      icon: Heart,
      title: 'Support Artisans',
      description: 'Every purchase directly benefits local craftspeople'
    }
  ];

  const testimonials = [
    {
      name: 'Priya Sharma',
      location: 'Delhi',
      text: 'Trawell helped me discover hidden gems in Rajasthan. The artisan marketplace is incredible!',
      rating: 5
    },
    {
      name: 'David Chen',
      location: 'Singapore',
      text: 'The AI planner created the perfect itinerary. I experienced India like never before.',
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center cultural-pattern">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 hero-gradient"></div>
        </div>
        
        <div className="relative z-10 container mx-auto px-6 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-playfair font-bold text-foreground mb-6">
              Discover the Heart of{' '}
              <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                Culture
              </span>{' '}
              with Trawell
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              AI-powered travel planning meets authentic artisan experiences in the cultural heart of India
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="btn-hero text-lg px-8 py-6" asChild>
                <Link to="/destinations">
                  <Compass className="mr-2" size={24} />
                  Start Your Journey
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8 py-6 bg-background/80" asChild>
                <Link to="/marketplace">
                  <ShoppingBag className="mr-2" size={24} />
                  Explore Marketplace
                </Link>
              </Button>
            </div>
          </div>
          
          {/* Floating Icons */}
          <div className="absolute top-1/4 left-1/4 animate-pulse">
            <div className="p-3 bg-primary/20 rounded-full">
              <MapPin className="h-6 w-6 text-primary" />
            </div>
          </div>
          <div className="absolute top-1/3 right-1/4 animate-pulse delay-1000">
            <div className="p-3 bg-secondary/20 rounded-full">
              <Heart className="h-6 w-6 text-secondary" />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-4">
              Why Choose <span className="text-primary">Trawell?</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              We blend cutting-edge technology with authentic cultural experiences
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="cultural-card text-center p-8">
                <CardContent className="space-y-4">
                  <div className="flex justify-center">
                    <div className="p-4 bg-primary/10 rounded-full">
                      <feature.icon className="h-10 w-10 text-primary" />
                    </div>
                  </div>
                  <h3 className="text-xl font-semibold">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Destinations */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-4">
                Explore <span className="text-secondary">Destinations</span>
              </h2>
              <p className="text-xl text-muted-foreground">
                Discover India's most culturally rich destinations
              </p>
            </div>
            <Button asChild variant="outline">
              <Link to="/destinations">
                View All
                <ArrowRight className="ml-2" size={20} />
              </Link>
            </Button>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {featuredDestinations.map((destination) => (
              <Card key={destination.id} className="cultural-card overflow-hidden group">
                <div className="aspect-video bg-muted relative overflow-hidden">
                  <img
                    src={destination.image}
                    alt={destination.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-white font-playfair text-xl font-bold mb-1">
                      {destination.name}
                    </h3>
                    <p className="text-white/80 text-sm">{destination.subtitle}</p>
                  </div>
                </div>
                
                <CardContent className="p-6 space-y-4">
                  <p className="text-muted-foreground">{destination.description}</p>
                  
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center space-x-1">
                      <Calendar size={16} />
                      <span>{destination.duration}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span>{destination.rating}</span>
                    </div>
                  </div>
                  
                  <Button className="w-full" asChild>
                    <Link to="/destinations">View Details</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Artisans */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-4">
                Meet Our <span className="text-accent">Artisans</span>
              </h2>
              <p className="text-xl text-muted-foreground">
                Support local craftspeople and bring home authentic treasures
              </p>
            </div>
            <Button asChild variant="outline">
              <Link to="/marketplace">
                Shop All
                <ArrowRight className="ml-2" size={20} />
              </Link>
            </Button>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {featuredArtisans.map((product) => (
              <Card key={product.id} className="cultural-card overflow-hidden group">
                <div className="aspect-square bg-muted relative overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <Badge className="absolute top-4 right-4 bg-accent">
                    New
                  </Badge>
                </div>
                
                <CardContent className="p-6 space-y-4">
                  <div>
                    <h3 className="font-playfair text-lg font-semibold mb-1">{product.name}</h3>
                    <p className="text-primary font-medium">by {product.artisan}</p>
                    <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                      <MapPin size={14} />
                      <span>{product.location}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="text-2xl font-bold text-primary">{product.price}</div>
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm">{product.rating}</span>
                    </div>
                  </div>
                  
                  <Button className="w-full" asChild>
                    <Link to="/marketplace">Buy Now</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-4">
              What Our <span className="text-primary">Travelers</span> Say
            </h2>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="cultural-card p-8">
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-muted-foreground italic">"{testimonial.text}"</p>
                  <div>
                    <p className="font-semibold">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary/10 to-secondary/10">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-4">
            Ready to Start Your Cultural Journey?
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Let our AI create a personalized itinerary that connects you with authentic experiences and local artisans
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="btn-hero text-lg px-8 py-6" asChild>
              <Link to="/destinations">
                <Users className="mr-2" size={24} />
                Plan My Trip
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="text-lg px-8 py-6" asChild>
              <Link to="/about">
                Learn More
              </Link>
            </Button>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default Index;