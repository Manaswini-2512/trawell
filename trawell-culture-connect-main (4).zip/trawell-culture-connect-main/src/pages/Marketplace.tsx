import { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Search, Heart, ShoppingCart, Star, MapPin } from 'lucide-react';
import artisanImage from '@/assets/artisan-pottery.jpg';
import silkImage from '@/assets/silk-textile.jpg';
import woodenElephantImage from '@/assets/wooden-elephant.jpg';
import brassDiyasImage from '@/assets/brass-diyas.jpg';
import pashminaShawlImage from '@/assets/pashmina-shawl.jpg';
import madhubaniPaintingImage from '@/assets/madhubani-painting.jpg';
import warliPaintingImage from '@/assets/warli-painting.jpg';
import khadiFabricImage from '@/assets/khadi-fabric.jpg';
import terracottaPotteryImage from '@/assets/terracotta-pottery.jpg';
import blockPrintFabricImage from '@/assets/block-print-fabric.jpg';
import silverJewelryImage from '@/assets/silver-jewelry.jpg';
import bambooBasketImage from '@/assets/bamboo-basket.jpg';
import glassBanglesImage from '@/assets/glass-bangles.jpg';
import embroideredBagImage from '@/assets/embroidered-bag.jpg';

const products = [
  {
    id: 1,
    name: 'Hand-painted Pottery',
    artisan: 'Raj Kumar',
    location: 'Jaipur',
    price: '₹1,200',
    originalPrice: '₹1,800',
    image: artisanImage,
    rating: 4.8,
    category: 'Pottery',
    description: 'Beautiful blue pottery with traditional Jaipur patterns'
  },
  {
    id: 2,
    name: 'Silk Saree',
    artisan: 'Lakshmi Devi',
    location: 'Varanasi',
    price: '₹2,800',
    originalPrice: '₹3,500',
    image: silkImage,
    rating: 4.9,
    category: 'Textiles',
    description: 'Pure Banarasi silk saree with gold zari work'
  },
  {
    id: 3,
    name: 'Wooden Elephant',
    artisan: 'Mohan Singh',
    location: 'Udaipur',
    price: '₹2,200',
    originalPrice: '₹3,200',
    image: woodenElephantImage,
    rating: 4.7,
    category: 'Wood Craft',
    description: 'Intricately carved wooden elephant with miniature paintings'
  },
  {
    id: 4,
    name: 'Brass Diya Set',
    artisan: 'Sunita Sharma',
    location: 'Moradabad',
    price: '₹800',
    originalPrice: '₹1,200',
    image: brassDiyasImage,
    rating: 4.6,
    category: 'Metal Craft',
    description: 'Set of 5 traditional brass oil lamps with engravings'
  },
  {
    id: 5,
    name: 'Pashmina Shawl',
    artisan: 'Abdul Rahman',
    location: 'Kashmir',
    price: '₹2,500',
    originalPrice: '₹3,200',
    image: pashminaShawlImage,
    rating: 4.8,
    category: 'Textiles',
    description: 'Pure cashmere pashmina with traditional Kashmiri embroidery'
  },
  {
    id: 6,
    name: 'Madhubani Painting',
    artisan: 'Gita Kumari',
    location: 'Bihar',
    price: '₹1,800',
    originalPrice: '₹2,500',
    image: madhubaniPaintingImage,
    rating: 4.9,
    category: 'Art',
    description: 'Traditional Madhubani painting on handmade paper'
  },
  {
    id: 7,
    name: 'Warli Painting',
    artisan: 'Meera Patel',
    location: 'Maharashtra',
    price: '₹1,500',
    originalPrice: '₹2,000',
    image: warliPaintingImage,
    rating: 4.7,
    category: 'Art',
    description: 'Authentic tribal art with traditional white patterns on canvas'
  },
  {
    id: 8,
    name: 'Khadi Cotton Fabric',
    artisan: 'Ganesh Weaver',
    location: 'Gujarat',
    price: '₹650',
    originalPrice: '₹900',
    image: khadiFabricImage,
    rating: 4.5,
    category: 'Textiles',
    description: 'Handspun and handwoven cotton fabric, symbol of Indian heritage'
  },
  {
    id: 9,
    name: 'Terracotta Pottery Set',
    artisan: 'Kamala Devi',
    location: 'West Bengal',
    price: '₹950',
    originalPrice: '₹1,400',
    image: terracottaPotteryImage,
    rating: 4.6,
    category: 'Pottery',
    description: 'Traditional earthenware pottery with natural clay finish'
  },
  {
    id: 10,
    name: 'Block Print Fabric',
    artisan: 'Ramesh Kumar',
    location: 'Rajasthan',
    price: '₹850',
    originalPrice: '₹1,200',
    image: blockPrintFabricImage,
    rating: 4.8,
    category: 'Textiles',
    description: 'Hand-block printed cotton with traditional Rajasthani patterns'
  },
  {
    id: 11,
    name: 'Silver Jewelry Set',
    artisan: 'Asha Silversmith',
    location: 'Rajasthan',
    price: '₹2,200',
    originalPrice: '₹2,800',
    image: silverJewelryImage,
    rating: 4.9,
    category: 'Jewelry',
    description: 'Oxidized silver jewelry with intricate filigree work'
  },
  {
    id: 12,
    name: 'Bamboo Basket',
    artisan: 'John Maring',
    location: 'Manipur',
    price: '₹450',
    originalPrice: '₹650',
    image: bambooBasketImage,
    rating: 4.4,
    category: 'Handicrafts',
    description: 'Eco-friendly handwoven bamboo basket from Northeast India'
  },
  {
    id: 13,
    name: 'Glass Bangles Set',
    artisan: 'Munni Begum',
    location: 'Firozabad',
    price: '₹280',
    originalPrice: '₹400',
    image: glassBanglesImage,
    rating: 4.3,
    category: 'Jewelry',
    description: 'Colorful glass bangles with traditional patterns and designs'
  },
  {
    id: 14,
    name: 'Embroidered Mirror Bag',
    artisan: 'Fatima Khan',
    location: 'Gujarat',
    price: '₹1,100',
    originalPrice: '₹1,600',
    image: embroideredBagImage,
    rating: 4.7,
    category: 'Textiles',
    description: 'Kutch embroidery bag with mirror work and vibrant threads'
  }
];

const Marketplace = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.artisan.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-playfair font-bold text-foreground mb-4">
            Artisan <span className="bg-gradient-to-r from-accent to-secondary bg-clip-text text-transparent">
              Marketplace
            </span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Support local artisans and bring home authentic handcrafted treasures from across India
          </p>
        </div>

        <div className="mb-8 space-y-4 md:space-y-0 md:flex md:items-center md:justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={20} />
            <Input
              type="text"
              placeholder="Search products, artisans, or regions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            {['All', 'Pottery', 'Textiles', 'Wood Craft', 'Metal Craft', 'Art', 'Jewelry', 'Handicrafts'].map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                onClick={() => setSelectedCategory(category)}
                size="sm"
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <Card key={product.id} className="cultural-card overflow-hidden group">
              <div className="aspect-square bg-muted relative overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <Button
                  size="sm"
                  variant="outline"
                  className="absolute top-4 right-4 bg-background/80 hover:bg-background"
                >
                  <Heart size={16} />
                </Button>
                <Badge className="absolute top-4 left-4 bg-accent">
                  {product.category}
                </Badge>
              </div>
              
              <CardHeader className="space-y-2">
                <div className="flex items-start justify-between">
                  <CardTitle className="text-lg font-playfair line-clamp-1">
                    {product.name}
                  </CardTitle>
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium">{product.rating}</span>
                  </div>
                </div>
                
                <div className="space-y-1">
                  <p className="text-primary font-medium">by {product.artisan}</p>
                  <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                    <MapPin size={14} />
                    <span>{product.location}</span>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <p className="text-muted-foreground text-sm line-clamp-2">{product.description}</p>
                
                <div className="flex items-center space-x-2">
                  <span className="text-2xl font-bold text-primary">{product.price}</span>
                  <span className="text-sm text-muted-foreground line-through">{product.originalPrice}</span>
                </div>
                
                <div className="flex space-x-2">
                  <Button className="flex-1 btn-hero">
                    <ShoppingCart size={16} className="mr-2" />
                    Buy Now
                  </Button>
                  <Button variant="outline" size="sm">
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Marketplace;